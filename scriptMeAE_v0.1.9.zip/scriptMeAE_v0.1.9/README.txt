scriptMe AE v0.1.9
INSTALL / UPDATE
1. Extract scriptMeAE_v0.1.9.zip and open the scriptMeAE_v0.1.9 folder.
2. Quit After Effects and back up your previous panel outside ScriptUI Panels.
3. Copy scriptMe_AE.jsx (keep that filename) into your AE ScriptUI Panels folder:
   macOS: /Applications/Adobe After Effects <version>/Scripts/ScriptUI Panels/
   Windows: C:\Program Files\Adobe\Adobe After Effects <version>\Support Files\Scripts\ScriptUI Panels\
   Administrator permission may be required. Replace the existing launcher.
4. Restart AE. Open scriptMe_AE from the Window menu and dock it.
5. Choose Library for your shared scripts. Open Project Scripts uses
   _scriptMeAE Files beside your saved AE project.

Double-click folders to expand/collapse and scripts to run. Refresh/Auto
discovers scripts without restarting AE. Updating the panel requires restart.
Enable Allow Scripts To Write Files And Access Network under Scripting &
Expressions when needed. Preserve your existing library/project script folders.

Version 0.1.9 downloads the ZIP directly instead of opening a GitHub page.
Installation is manual. The versioned outer folder identifies this download;
the installed JSX filename stays scriptMe_AE.jsx to prevent duplicate panels.
Drew accepted this version's direct-download flow; broader OS/AE testing remains
incomplete.
