scriptMe AE v0.1.8 - Installation

This ZIP contains:
  scriptMe_AE.jsx - the After Effects panel
  README.txt - these instructions

INSTALL / UPDATE (macOS and Windows)
1. Extract this ZIP.
2. Quit After Effects. Keep your previous launcher as a backup outside the
   Scripts/ScriptUI Panels folder.
3. Copy scriptMe_AE.jsx into Scripts/ScriptUI Panels inside the installation
   folder for the After Effects version you use. Replace the existing file
   with that exact name. Administrator permission may be required.
   macOS: typically /Applications/Adobe After Effects <version>/Scripts/ScriptUI Panels/
   Windows: typically C:\Program Files\Adobe\Adobe After Effects <version>\Support Files\Scripts\ScriptUI Panels\
4. Start After Effects. Select scriptMe_AE from the Window menu and dock it.
5. Choose your persistent script library. For project-specific scripts, save
   your AE project and click Open Project Scripts. These scripts live in
   _scriptMeAE Files beside the project file.

Double-click folders to expand/collapse and scripts to run them. Run Script
also runs the selected script. Refresh or Auto discovers new scripts without
restarting AE. Replacing this panel itself requires restarting AE.

Enable Allow Scripts To Write Files And Access Network in AE's Scripting &
Expressions preferences when needed. Library preferences and project scripts
are separate from the installed JSX; do not remove those folders to update.

v0.1.8 changes: simplified bottom controls and manual version check with
change notes. This version's download action still opens the repository page;
the direct ZIP action is being tested in the next version.

Drew reported v0.1.8 works as expected in AE. This is not comprehensive testing
across all AE/macOS/Windows versions. Installation remains manual.

